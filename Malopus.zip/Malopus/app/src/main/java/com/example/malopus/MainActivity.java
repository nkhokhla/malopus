package com.example.malopus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView bottomNavigationView = (BottomNavigationView)findViewById(R.id.navigation);
        bottomNavigationView.getMenu().findItem(R.id.home).setChecked(true);
        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                        bottomNavigationView.getMenu().findItem(R.id.library).setChecked(false);
//                        bottomNavigationView.getMenu().findItem(R.id.news).setChecked(false);
//                        bottomNavigationView.getMenu().findItem(R.id.guides).setChecked(false);
                        switch (item.getItemId()) {
                            case R.id.home:

                            case R.id.library:
                                Intent intent = new Intent(MainActivity.this, Library.class);
                                startActivity(intent);
                            case R.id.news:
                                Intent intent1 = new Intent(MainActivity.this, News.class);
                                startActivity(intent1);
                            case R.id.guides:
                                Intent intent2 = new Intent(MainActivity.this, Guides.class);
                                startActivity(intent2);
                        }
                        return true;
                    }
                });

    }

}
